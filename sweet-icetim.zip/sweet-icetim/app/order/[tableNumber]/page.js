'use client';

import { use, useEffect, useMemo, useState } from 'react';
import { supabase } from '../../../lib/supabaseClient';

const MAX_QTY = 99;

export default function OrderPage({ params }) {
  // params เป็น Promise ใน Next.js เวอร์ชันล่าสุด ต้อง unwrap ด้วย use()
  const { tableNumber } = use(params);
  const table = Number(tableNumber);
  const validTable = /^\d+$/.test(tableNumber) && table >= 1;

  // loading | ready | no-session | invalid | error
  const [phase, setPhase] = useState(validTable ? 'loading' : 'invalid');
  const [session, setSession] = useState(null);
  const [categories, setCategories] = useState([]);
  const [items, setItems] = useState([]);
  const [cart, setCart] = useState({}); // { [menuItemId]: qty }

  const [submitting, setSubmitting] = useState(false);
  const [submitError, setSubmitError] = useState('');
  const [sent, setSent] = useState(false);

  useEffect(() => {
    if (!validTable) return;
    let cancelled = false;

    async function load() {
      setPhase('loading');
      try {
        const [sessionRes, catRes, itemRes] = await Promise.all([
          supabase
            .from('sessions')
            .select('id, table_number')
            .eq('table_number', table)
            .eq('status', 'open')
            .order('created_at', { ascending: false })
            .limit(1),
          supabase
            .from('menu_categories')
            .select('id, name, sort_order')
            .order('sort_order', { ascending: true }),
          supabase.from('menu_items').select('id, category_id, name'),
        ]);

        if (sessionRes.error) throw sessionRes.error;
        if (catRes.error) throw catRes.error;
        if (itemRes.error) throw itemRes.error;
        if (cancelled) return;

        const openSession = sessionRes.data?.[0] ?? null;
        setCategories(catRes.data ?? []);
        setItems(itemRes.data ?? []);
        setSession(openSession);
        setPhase(openSession ? 'ready' : 'no-session');
      } catch (err) {
        console.error(err);
        if (!cancelled) setPhase('error');
      }
    }

    load();
    return () => {
      cancelled = true;
    };
  }, [table, validTable]);

  const sections = useMemo(
    () =>
      categories
        .map((cat) => ({
          ...cat,
          items: items.filter((it) => it.category_id === cat.id),
        }))
        .filter((cat) => cat.items.length > 0),
    [categories, items]
  );

  const totalQty = Object.values(cart).reduce((sum, q) => sum + q, 0);

  function changeQty(id, delta) {
    setSubmitError('');
    setCart((prev) => {
      const next = Math.min(MAX_QTY, Math.max(0, (prev[id] ?? 0) + delta));
      const copy = { ...prev };
      if (next === 0) delete copy[id];
      else copy[id] = next;
      return copy;
    });
  }

  async function handleSubmit() {
    if (totalQty === 0 || !session) return;
    setSubmitting(true);
    setSubmitError('');
    try {
      // เช็คอีกครั้งว่าโต๊ะยังเปิดอยู่ (พนักงานอาจปิดโต๊ะไปแล้ว)
      const { data: stillOpen, error: checkError } = await supabase
        .from('sessions')
        .select('id')
        .eq('id', session.id)
        .eq('status', 'open')
        .limit(1);
      if (checkError) throw checkError;
      if (!stillOpen || stillOpen.length === 0) {
        setSession(null);
        setPhase('no-session');
        return;
      }

      const lines = items
        .filter((it) => cart[it.id] > 0)
        .map((it) => ({ item_id: it.id, name: it.name, qty: cart[it.id] }));

      const { error: insertError } = await supabase.from('orders').insert({
        session_id: session.id,
        table_number: table,
        items: lines,
        status: 'pending',
      });
      if (insertError) throw insertError;

      setCart({});
      setSent(true);
    } catch (err) {
      console.error(err);
      setSubmitError('ส่งออเดอร์ไม่สำเร็จ กรุณาลองใหม่อีกครั้ง');
    } finally {
      setSubmitting(false);
    }
  }

  // ---------- สถานะต่าง ๆ ----------
  if (phase === 'invalid') {
    return (
      <main className="order-page">
        <div className="order-notice">
          <h1>ลิงก์ไม่ถูกต้อง</h1>
          <p>กรุณาสแกน QR ที่โต๊ะอีกครั้ง หรือเรียกพนักงาน</p>
        </div>
      </main>
    );
  }

  if (phase === 'loading') {
    return (
      <main className="order-page">
        <div className="order-notice">
          <p>กำลังโหลดเมนู...</p>
        </div>
      </main>
    );
  }

  if (phase === 'error') {
    return (
      <main className="order-page">
        <div className="order-notice">
          <h1>โหลดข้อมูลไม่สำเร็จ</h1>
          <p>กรุณาลองรีเฟรชหน้านี้ ถ้ายังไม่ได้ให้เรียกพนักงาน</p>
        </div>
      </main>
    );
  }

  if (phase === 'no-session') {
    return (
      <main className="order-page">
        <div className="order-notice">
          <h1>โต๊ะ {table}</h1>
          <p>โต๊ะนี้ยังไม่เปิดให้สั่งอาหาร กรุณาติดต่อพนักงาน</p>
        </div>
      </main>
    );
  }

  if (sent) {
    return (
      <main className="order-page">
        <div className="order-notice">
          <h1>ส่งออเดอร์แล้ว</h1>
          <p>ครัวได้รับออเดอร์ของโต๊ะ {table} แล้ว</p>
          <button
            type="button"
            className="btn btn-primary"
            onClick={() => setSent(false)}
          >
            สั่งเพิ่ม
          </button>
        </div>
      </main>
    );
  }

  // ---------- หน้าสั่งอาหาร ----------
  return (
    <main className="order-page has-bar">
      <header className="order-header">
        <h1>สวีทไอติม</h1>
        <p>โต๊ะ {table}</p>
      </header>

      {sections.length === 0 && (
        <div className="order-notice">
          <p>ยังไม่มีรายการอาหารในเมนู</p>
        </div>
      )}

      {sections.map((cat) => (
        <section key={cat.id} className="menu-section">
          <h2>{cat.name}</h2>
          <ul>
            {cat.items.map((it) => {
              const qty = cart[it.id] ?? 0;
              return (
                <li key={it.id} className="menu-item">
                  <span className="menu-item-name">{it.name}</span>
                  <div className="stepper">
                    <button
                      type="button"
                      onClick={() => changeQty(it.id, -1)}
                      disabled={qty === 0}
                      aria-label={`ลด ${it.name}`}
                    >
                      −
                    </button>
                    <span aria-live="polite">{qty}</span>
                    <button
                      type="button"
                      onClick={() => changeQty(it.id, 1)}
                      disabled={qty >= MAX_QTY}
                      aria-label={`เพิ่ม ${it.name}`}
                    >
                      +
                    </button>
                  </div>
                </li>
              );
            })}
          </ul>
        </section>
      ))}

      <div className="order-bar">
        {submitError && (
          <p className="form-error" role="alert">
            {submitError}
          </p>
        )}
        <button
          type="button"
          className="btn btn-primary btn-block"
          onClick={handleSubmit}
          disabled={totalQty === 0 || submitting}
        >
          {submitting
            ? 'กำลังส่ง...'
            : totalQty === 0
              ? 'เลือกรายการก่อนส่งออเดอร์'
              : `ส่งออเดอร์ (${totalQty} รายการ)`}
        </button>
      </div>
    </main>
  );
}
